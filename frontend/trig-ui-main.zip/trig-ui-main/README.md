## **UI for [trig](https://github.com/DotSlash-A/trig)**

- Go to [bolt](./bolt) and run `npm install && npm run dev`
- Go to [gemini](./gemini/) and run `./run.sh`
- Go to [o3](./o3) and run `npm install && npm run dev`
- Go to [v0](./v0) and run `npm install && npm run dev`