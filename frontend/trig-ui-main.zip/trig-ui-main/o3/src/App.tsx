import React, { useState } from 'react';
import axios from 'axios';
import { Tab } from '@headlessui/react';
import { motion } from 'framer-motion';

function App() {
  const [simpleDiffExpr, setSimpleDiffExpr] = useState('x**2 * sin(x)');
  const [simpleDiffVar, setSimpleDiffVar] = useState('x');
  const [simpleDiffResult, setSimpleDiffResult] = useState(null);

  const [stepsDiffExpr, setStepsDiffExpr] = useState('x**2 * sin(x)');
  const [stepsDiffVar, setStepsDiffVar] = useState('x');
  const [stepsDiffResult, setStepsDiffResult] = useState(null);

  const [simpleIntExpr, setSimpleIntExpr] = useState('x**2 * sin(x)');
  const [simpleIntVar, setSimpleIntVar] = useState('x');
  const [simpleIntResult, setSimpleIntResult] = useState(null);

  const [stepsIntExpr, setStepsIntExpr] = useState('x**2 * sin(x)');
  const [stepsIntVar, setStepsIntVar] = useState('x');
  const [stepsIntResult, setStepsIntResult] = useState(null);

  const [slopeInputs, setSlopeInputs] = useState({ x1: '', y1: '', x2: '', y2: '' });
  const [slopeResult, setSlopeResult] = useState(null);

  const [powerN, setPowerN] = useState('');
  const [powerResult, setPowerResult] = useState(null);

  const [complexOp, setComplexOp] = useState('add');
  const [z1, setZ1] = useState({ real: '', img: '' });
  const [z2, setZ2] = useState({ real: '', img: '' });
  const [complexResult, setComplexResult] = useState(null);

  const [circleCenter, setCircleCenter] = useState({ h: '', k: '', r: '' });
  const [circleCenterResult, setCircleCenterResult] = useState(null);

  const [circleGeneral, setCircleGeneral] = useState('x^2 - 2.0*x + 1.0*y^2 - 4.0*y - 20.0 = 0');
  const [circleGeneralResult, setCircleGeneralResult] = useState(null);

  const [circle3Points, setCircle3Points] = useState({
    p: { x: '', y: '' },
    q: { x: '', y: '' },
    r: { x: '', y: '' }
  });
  const [circle3PointsResult, setCircle3PointsResult] = useState(null);
  const [circle3DetResult, setCircle3DetResult] = useState(null);

  const api = axios.create({ baseURL: 'http://localhost:8000' });

  const callApi = async (endpoint, payload, setter) => {
    try {
      const res = await api.post(endpoint, payload);
      setter(res.data);
    } catch (err) {
      setter({ error: err.message });
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-center">Math API Dashboard</h1>
      <Tab.Group>
        <Tab.List className="flex space-x-1 bg-blue-100 p-2 rounded-xl">
          {[
            'Diff Simple', 'Diff Steps', 'Int Simple', 'Int Steps', 'Slope', 'Power i',
            'Complex', 'Circle Center', 'Circle Eqn', '3Points', '3Points Det'
          ].map((tab) => (
            <Tab
              key={tab}
              className={({ selected }) =>
                `w-full py-2.5 text-sm leading-5 font-medium rounded-lg focus:outline-none ${selected ? 'bg-white shadow' : 'text-blue-700 hover:bg-white/[0.12]'
                }`
              }
            >
              {tab}
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels className="mt-4">
          {/* Simple Differentiate */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-2 gap-4">
                <input
                  value={simpleDiffExpr}
                  onChange={(e) => setSimpleDiffExpr(e.target.value)}
                  placeholder="Expression"
                  className="p-2 border rounded"
                />
                <input
                  value={simpleDiffVar}
                  onChange={(e) => setSimpleDiffVar(e.target.value)}
                  placeholder="Variable"
                  className="p-2 border rounded"
                />
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/differentiate/simple', { expression: simpleDiffExpr, variable: simpleDiffVar }, setSimpleDiffResult)}
              >
                Compute
              </button>
              {simpleDiffResult && (
                <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(simpleDiffResult, null, 2)}</pre>
              )}
            </motion.div>
          </Tab.Panel>
          {/* Steps Differentiate */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-2 gap-4">
                <input
                  value={stepsDiffExpr}
                  onChange={(e) => setStepsDiffExpr(e.target.value)}
                  placeholder="Expression"
                  className="p-2 border rounded"
                />
                <input
                  value={stepsDiffVar}
                  onChange={(e) => setStepsDiffVar(e.target.value)}
                  placeholder="Variable"
                  className="p-2 border rounded"
                />
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/differentiate/steps', { expression: stepsDiffExpr, variable: stepsDiffVar }, setStepsDiffResult)}
              >
                Compute Steps
              </button>
              {stepsDiffResult && (
                <pre className="mt-4 p-4 bg-gray-100 rounded whitespace-pre-wrap">{JSON.stringify(stepsDiffResult, null, 2)}</pre>
              )}
            </motion.div>
          </Tab.Panel>
          {/* Integrate Simple */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-2 gap-4">
                <input
                  value={simpleIntExpr}
                  onChange={(e) => setSimpleIntExpr(e.target.value)}
                  placeholder="Expression"
                  className="p-2 border rounded"
                />
                <input
                  value={simpleIntVar}
                  onChange={(e) => setSimpleIntVar(e.target.value)}
                  placeholder="Variable"
                  className="p-2 border rounded"
                />
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/integrate/integrate/simple', { expression: simpleIntExpr, variable: simpleIntVar }, setSimpleIntResult)}
              >
                Compute
              </button>
              {simpleIntResult && (
                <pre className="mt-4 p-4 bg-gray-100 rounded whitespace-pre-wrap">{JSON.stringify(simpleIntResult, null, 2)}</pre>
              )}
            </motion.div>
          </Tab.Panel>
          {/* Integrate Steps */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-2 gap-4">
                <input
                  value={stepsIntExpr}
                  onChange={(e) => setStepsIntExpr(e.target.value)}
                  placeholder="Expression"
                  className="p-2 border rounded"
                />
                <input
                  value={stepsIntVar}
                  onChange={(e) => setStepsIntVar(e.target.value)}
                  placeholder="Variable"
                  className="p-2 border rounded"
                />
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/integrate/integrate/steps', { expression: stepsIntExpr, variable: stepsIntVar }, setStepsIntResult)}
              >
                Compute Steps
              </button>
              {stepsIntResult && (
                <pre className="mt-4 p-4 bg-gray-100 rounded whitespace-pre-wrap">{JSON.stringify(stepsIntResult, null, 2)}</pre>
              )}
            </motion.div>
          </Tab.Panel>
          {/* Slope */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-4 gap-4">
                {['x1', 'y1', 'x2', 'y2'].map((coord) => (
                  <input
                    key={coord}
                    value={slopeInputs[coord]}
                    onChange={(e) => setSlopeInputs({ ...slopeInputs, [coord]: e.target.value })}
                    placeholder={coord}
                    className="p-2 border rounded"
                  />
                ))}
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/SlopeCordiantes', { ...slopeInputs }, setSlopeResult)}
              >
                Compute Slope
              </button>
              {slopeResult && <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(slopeResult, null, 2)}</pre>}
            </motion.div>
          </Tab.Panel>
          {/* Power of i */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <input
                value={powerN}
                onChange={(e) => setPowerN(e.target.value)}
                placeholder="n"
                className="p-2 border rounded"
              />
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi(`/powers?n=${powerN}`, {}, setPowerResult)}
              >
                Compute i^n
              </button>
              {powerResult && <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(powerResult, null, 2)}</pre>}
            </motion.div>
          </Tab.Panel>
          {/* Complex Arithmetic */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-2 gap-4">
                <fieldset className="border p-2 rounded">
                  <legend>Z1</legend>
                  <input
                    value={z1.real}
                    onChange={(e) => setZ1({ ...z1, real: e.target.value })}
                    placeholder="real"
                    className="p-1 border rounded w-full mb-1"
                  />
                  <input
                    value={z1.img}
                    onChange={(e) => setZ1({ ...z1, img: e.target.value })}
                    placeholder="imag"
                    className="p-1 border rounded w-full"
                  />
                </fieldset>
                <fieldset className="border p-2 rounded">
                  <legend>Z2</legend>
                  <input
                    value={z2.real}
                    onChange={(e) => setZ2({ ...z2, real: e.target.value })}
                    placeholder="real"
                    className="p-1 border rounded w-full mb-1"
                  />
                  <input
                    value={z2.img}
                    onChange={(e) => setZ2({ ...z2, img: e.target.value })}
                    placeholder="imag"
                    className="p-1 border rounded w-full"
                  />
                </fieldset>
                <select
                  value={complexOp}
                  onChange={(e) => setComplexOp(e.target.value)}
                  className="p-2 border rounded"
                >
                  {['add', 'subtract', 'multiply', 'divide'].map((op) => <option key={op} value={op}>{op}</option>)}
                </select>
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/arithmetic', { z1: { real: Number(z1.real), img: Number(z1.img) }, z2: { real: Number(z2.real), img: Number(z2.img) }, operation: complexOp }, setComplexResult)}
              >
                Compute
              </button>
              {complexResult && <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(complexResult, null, 2)}</pre>}
            </motion.div>
          </Tab.Panel>
          {/* Circle Center/Radius */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-3 gap-4">
                {['h', 'k', 'r'].map((field) => (
                  <input
                    key={field}
                    value={circleCenter[field]}
                    onChange={(e) => setCircleCenter({ ...circleCenter, [field]: e.target.value })}
                    placeholder={field}
                    className="p-2 border rounded"
                  />
                ))}
              </div>
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/circle/eqn', { h: Number(circleCenter.h), k: Number(circleCenter.k), r: Number(circleCenter.r) }, setCircleCenterResult)}
              >
                Compute Equation
              </button>
              {circleCenterResult && <pre className="mt-4 p-4 bg-gray-100 rounded whitespace-pre-wrap">{JSON.stringify(circleCenterResult, null, 2)}</pre>}
            </motion.div>
          </Tab.Panel>
          {/* Circle General Details */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <input
                value={circleGeneral}
                onChange={(e) => setCircleGeneral(e.target.value)}
                placeholder="General Equation"
                className="w-full p-2 border rounded"
              />
              <button
                className="mt-4 px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                onClick={() => callApi('/circle/details', { equation: circleGeneral }, setCircleGeneralResult)}
              >
                Compute Details
              </button>
              {circleGeneralResult && <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(circleGeneralResult, null, 2)}</pre>}
            </motion.div>
          </Tab.Panel>
          {/* Circle 3 Points */}
          <Tab.Panel>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="grid grid-cols-3 gap-4">
                {['p', 'q', 'r'].map((pt) => (
                  <fieldset key={pt} className="border p-2 rounded">
                    <legend>{pt.toUpperCase()}</legend>
                    <input
                      value={circle3Points[pt].x}
                      onChange={(e) => setCircle3Points({ ...circle3Points, [pt]: { ...circle3Points[pt], x: e.target.value } })}
                      placeholder="x"
                      className="p-1 border rounded w-full mb-1"
                    />
                    <input
                      value={circle3Points[pt].y}
                      onChange={(e) => setCircle3Points({ ...circle3Points, [pt]: { ...circle3Points[pt], y: e.target.value } })}
                      placeholder="y"
                      className="p-1 border rounded w-full"
                    />
                  </fieldset>
                ))}
              </div>
              <div className="flex space-x-4 mt-4">
                <button
                  className="px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                  onClick={() => callApi('/circle/3points', circle3Points, setCircle3PointsResult)}
                >
                  Compute Standard
                </button>
                <button
                  className="px-4 py-2 bg-indigo-500 text-white rounded shadow hover:bg-indigo-600"
                  onClick={() => callApi('/circle/3points/det1', circle3Points, setCircle3DetResult)}
                >
                  Compute Determinant
                </button>
              </div>
              {circle3PointsResult && <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(circle3PointsResult, null, 2)}</pre>}
              {circle3DetResult && <pre className="mt-4 p-4 bg-gray-100 rounded">{JSON.stringify(circle3DetResult, null, 2)}</pre>}
            </motion.div>
          </Tab.Panel>
        </Tab.Panels>
      </Tab.Group>
    </div>
  );
}

export default App;
