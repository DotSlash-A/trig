"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle, ArrowRight } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface DifferentiateResponse {
  original_expression: string
  variable: string
  derivative: string
}

export default function DifferentiateSimple() {
  const [expression, setExpression] = useState("x**2 * sin(x)")
  const [variable, setVariable] = useState("x")
  const [result, setResult] = useState<DifferentiateResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:8000/differentiate/simple", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          expression,
          variable,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to differentiate expression")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Differentiate</CardTitle>
        <CardDescription>Calculate the derivative of a mathematical expression</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="expression" className="text-sm font-medium">
              Expression
            </label>
            <Input
              id="expression"
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              placeholder="e.g., x**2 * sin(x)"
              required
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="variable" className="text-sm font-medium">
              Variable
            </label>
            <Input
              id="variable"
              value={variable}
              onChange={(e) => setVariable(e.target.value)}
              placeholder="e.g., x"
              required
            />
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Differentiate"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4 space-y-2">
            <div className="flex items-center gap-2 rounded-md bg-slate-100 p-3 dark:bg-slate-800">
              <div className="text-sm">
                <div className="font-medium">Original:</div>
                <div className="font-mono">{result.original_expression}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ArrowRight className="h-4 w-4 text-slate-400" />
            </div>
            <div className="rounded-md bg-emerald-50 p-3 dark:bg-emerald-950/30">
              <div className="text-sm">
                <div className="font-medium">Derivative:</div>
                <div className="font-mono">{result.derivative}</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
