"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface CircleEquationResponse {
  standard_form: string
  general_form: string
  center_h: number
  center_k: number
  radius: number
  A: number
  B: number
  C: number
  D: number
  E: number
}

export default function CircleEquation() {
  const [radius, setRadius] = useState("5")
  const [centerH, setCenterH] = useState("1")
  const [centerK, setCenterK] = useState("2")
  const [result, setResult] = useState<CircleEquationResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:8000/circle/eqn", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          r: Number.parseFloat(radius),
          h: Number.parseFloat(centerH),
          k: Number.parseFloat(centerK),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to calculate circle equation")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Circle Equation</CardTitle>
        <CardDescription>Calculate the equation of a circle from center and radius</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label htmlFor="center-h" className="text-sm font-medium">
                Center (h)
              </label>
              <Input
                id="center-h"
                value={centerH}
                onChange={(e) => setCenterH(e.target.value)}
                type="number"
                step="any"
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="center-k" className="text-sm font-medium">
                Center (k)
              </label>
              <Input
                id="center-k"
                value={centerK}
                onChange={(e) => setCenterK(e.target.value)}
                type="number"
                step="any"
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="radius" className="text-sm font-medium">
                Radius (r)
              </label>
              <Input
                id="radius"
                value={radius}
                onChange={(e) => setRadius(e.target.value)}
                type="number"
                step="any"
                min="0"
                required
              />
            </div>
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Calculate Equation"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4 space-y-4">
            <div className="rounded-md bg-slate-50 p-3 dark:bg-slate-900">
              <div className="text-sm">
                <div className="font-medium">Standard Form:</div>
                <div className="font-mono">{result.standard_form}</div>
              </div>
            </div>

            <div className="rounded-md bg-slate-50 p-3 dark:bg-slate-900">
              <div className="text-sm">
                <div className="font-medium">General Form:</div>
                <div className="font-mono">{result.general_form}</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-md bg-emerald-50 p-3 dark:bg-emerald-950/30">
                <div className="text-sm text-center">
                  <div className="font-medium">Center (h, k)</div>
                  <div className="font-bold">
                    ({result.center_h}, {result.center_k})
                  </div>
                </div>
              </div>
              <div className="rounded-md bg-emerald-50 p-3 dark:bg-emerald-950/30">
                <div className="text-sm text-center">
                  <div className="font-medium">Radius (r)</div>
                  <div className="font-bold">{result.radius}</div>
                </div>
              </div>
              <div className="rounded-md bg-emerald-50 p-3 dark:bg-emerald-950/30">
                <div className="text-sm text-center">
                  <div className="font-medium">Coefficients</div>
                  <div className="font-bold">
                    A={result.A}, B={result.B}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
