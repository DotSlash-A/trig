"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface Step {
  step_description: string
  expression_latex: string
  expression_pretty: string
}

interface IntegrateStepsResponse {
  original_expression: string
  variable: string
  steps: Step[]
  final_integral: string
  computation_notes: string | null
}

export default function IntegrateSteps() {
  const [expression, setExpression] = useState("x**2 * sin(x)")
  const [variable, setVariable] = useState("x")
  const [result, setResult] = useState<IntegrateStepsResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:8000/integrate/integrate/steps", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          expression,
          variable,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to integrate expression")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Integrate with Steps</CardTitle>
        <CardDescription>Calculate the integral with step-by-step explanation</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="expression-integrate-steps" className="text-sm font-medium">
              Expression
            </label>
            <Input
              id="expression-integrate-steps"
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              placeholder="e.g., x**2 * sin(x)"
              required
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="variable-integrate-steps" className="text-sm font-medium">
              Variable
            </label>
            <Input
              id="variable-integrate-steps"
              value={variable}
              onChange={(e) => setVariable(e.target.value)}
              placeholder="e.g., x"
              required
            />
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Integrate with Steps"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4 space-y-4">
            <div className="rounded-md bg-slate-100 p-3 dark:bg-slate-800">
              <div className="text-sm">
                <div className="font-medium">Original:</div>
                <div className="font-mono">{result.original_expression}</div>
              </div>
            </div>

            <div className="space-y-3">
              {result.steps.map((step, index) => (
                <div key={index} className="rounded-md bg-slate-50 p-3 dark:bg-slate-900">
                  <div className="text-sm">
                    <div className="font-medium">{step.step_description}</div>
                    {step.expression_pretty && (
                      <div className="mt-1 font-mono whitespace-pre-wrap">{step.expression_pretty}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-md bg-emerald-50 p-3 dark:bg-emerald-950/30">
              <div className="text-sm">
                <div className="font-medium">Final Integral:</div>
                <div className="font-mono whitespace-pre-wrap">{result.final_integral}</div>
              </div>
            </div>

            {result.computation_notes && (
              <div className="rounded-md bg-slate-50 p-3 dark:bg-slate-900">
                <div className="text-sm">
                  <div className="font-medium">Notes:</div>
                  <div>{result.computation_notes}</div>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
