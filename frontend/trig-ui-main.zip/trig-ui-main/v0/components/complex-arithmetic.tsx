"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ArithmeticResponse {
  result: string
}

export default function ComplexArithmetic() {
  const [real1, setReal1] = useState("2")
  const [img1, setImg1] = useState("3")
  const [real2, setReal2] = useState("1")
  const [img2, setImg2] = useState("2")
  const [operation, setOperation] = useState("add")
  const [result, setResult] = useState<ArithmeticResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:8000/arithmetic", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          z1: {
            real: Number.parseFloat(real1),
            img: Number.parseFloat(img1),
          },
          z2: {
            real: Number.parseFloat(real2),
            img: Number.parseFloat(img2),
          },
          operation,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to perform complex arithmetic")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Complex Number Arithmetic</CardTitle>
        <CardDescription>Perform operations on complex numbers</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">First Complex Number (z₁)</label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="real1" className="text-xs text-slate-500">
                    Real Part
                  </label>
                  <Input
                    id="real1"
                    value={real1}
                    onChange={(e) => setReal1(e.target.value)}
                    type="number"
                    step="any"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="img1" className="text-xs text-slate-500">
                    Imaginary Part
                  </label>
                  <Input
                    id="img1"
                    value={img1}
                    onChange={(e) => setImg1(e.target.value)}
                    type="number"
                    step="any"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Second Complex Number (z₂)</label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="real2" className="text-xs text-slate-500">
                    Real Part
                  </label>
                  <Input
                    id="real2"
                    value={real2}
                    onChange={(e) => setReal2(e.target.value)}
                    type="number"
                    step="any"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="img2" className="text-xs text-slate-500">
                    Imaginary Part
                  </label>
                  <Input
                    id="img2"
                    value={img2}
                    onChange={(e) => setImg2(e.target.value)}
                    type="number"
                    step="any"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="operation" className="text-sm font-medium">
                Operation
              </label>
              <Select value={operation} onValueChange={setOperation}>
                <SelectTrigger id="operation">
                  <SelectValue placeholder="Select operation" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="add">Addition (z₁ + z₂)</SelectItem>
                  <SelectItem value="subtract">Subtraction (z₁ - z₂)</SelectItem>
                  <SelectItem value="multiply">Multiplication (z₁ × z₂)</SelectItem>
                  <SelectItem value="divide">Division (z₁ ÷ z₂)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Calculate"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4">
            <div className="rounded-md bg-emerald-50 p-4 dark:bg-emerald-950/30">
              <div className="text-center">
                <div className="text-sm font-medium">Result:</div>
                <div className="text-2xl font-bold">{result.result}</div>
                <div className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  {`(${real1} ${img1 >= 0 ? "+" : ""}${img1}i) ${
                    operation === "add" ? "+" : operation === "subtract" ? "-" : operation === "multiply" ? "×" : "÷"
                  } (${real2} ${img2 >= 0 ? "+" : ""}${img2}i)`}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
