"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface PowerResponse {
  result: number
}

export default function PowerOfI() {
  const [power, setPower] = useState("4")
  const [result, setResult] = useState<PowerResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`http://localhost:8000/powers?n=${power}`, {
        method: "POST",
        headers: {
          accept: "application/json",
        },
      })

      if (!response.ok) {
        throw new Error("Failed to calculate power of i")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Power of i</CardTitle>
        <CardDescription>Calculate i raised to a power (i^n)</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="power" className="text-sm font-medium">
              Power (n)
            </label>
            <Input id="power" value={power} onChange={(e) => setPower(e.target.value)} type="number" required />
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Calculate i^n"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4">
            <div className="rounded-md bg-emerald-50 p-4 dark:bg-emerald-950/30">
              <div className="text-center">
                <div className="text-sm font-medium">
                  i<sup>{power}</sup> =
                </div>
                <div className="text-2xl font-bold">{result.result}</div>
                <div className="mt-2 text-sm text-slate-500 dark:text-slate-400">i raised to the power of {power}</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
