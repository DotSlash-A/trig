"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface CircleFromPointsResponse {
  standard_form: string
}

export default function CircleFromPoints() {
  const [x1, setX1] = useState("4")
  const [y1, setY1] = useState("3")
  const [x2, setX2] = useState("-4")
  const [y2, setY2] = useState("3")
  const [x3, setX3] = useState("4")
  const [y3, setY3] = useState("-3")
  const [result, setResult] = useState<CircleFromPointsResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:8000/circle/3points", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          p: {
            x: Number.parseFloat(x1),
            y: Number.parseFloat(y1),
          },
          q: {
            x: Number.parseFloat(x2),
            y: Number.parseFloat(y2),
          },
          r: {
            x: Number.parseFloat(x3),
            y: Number.parseFloat(y3),
          },
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to calculate circle from points")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Circle from 3 Points</CardTitle>
        <CardDescription>Calculate circle equation from three points on the circle</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Point 1</label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="x1" className="text-xs text-slate-500">
                    X₁
                  </label>
                  <Input id="x1" value={x1} onChange={(e) => setX1(e.target.value)} type="number" step="any" required />
                </div>
                <div className="space-y-2">
                  <label htmlFor="y1" className="text-xs text-slate-500">
                    Y₁
                  </label>
                  <Input id="y1" value={y1} onChange={(e) => setY1(e.target.value)} type="number" step="any" required />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Point 2</label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="x2" className="text-xs text-slate-500">
                    X₂
                  </label>
                  <Input id="x2" value={x2} onChange={(e) => setX2(e.target.value)} type="number" step="any" required />
                </div>
                <div className="space-y-2">
                  <label htmlFor="y2" className="text-xs text-slate-500">
                    Y₂
                  </label>
                  <Input id="y2" value={y2} onChange={(e) => setY2(e.target.value)} type="number" step="any" required />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Point 3</label>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="x3" className="text-xs text-slate-500">
                    X₃
                  </label>
                  <Input id="x3" value={x3} onChange={(e) => setX3(e.target.value)} type="number" step="any" required />
                </div>
                <div className="space-y-2">
                  <label htmlFor="y3" className="text-xs text-slate-500">
                    Y₃
                  </label>
                  <Input id="y3" value={y3} onChange={(e) => setY3(e.target.value)} type="number" step="any" required />
                </div>
              </div>
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Calculate Circle"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4">
            <div className="rounded-md bg-emerald-50 p-4 dark:bg-emerald-950/30">
              <div className="text-sm">
                <div className="font-medium">Circle Equation:</div>
                <div className="font-mono">{result.standard_form}</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
