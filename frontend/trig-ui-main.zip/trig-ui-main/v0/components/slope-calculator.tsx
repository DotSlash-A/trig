"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface SlopeResponse {
  slope: number
}

export default function SlopeCalculator() {
  const [x1, setX1] = useState("1")
  const [y1, setY1] = useState("2")
  const [x2, setX2] = useState("5")
  const [y2, setY2] = useState("7")
  const [result, setResult] = useState<SlopeResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:8000/SlopeCordiantes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          x1: Number.parseFloat(x1),
          y1: Number.parseFloat(y1),
          x2: Number.parseFloat(x2),
          y2: Number.parseFloat(y2),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to calculate slope")
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Slope Calculator</CardTitle>
        <CardDescription>Calculate the slope between two points</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label htmlFor="x1" className="text-sm font-medium">
                X₁
              </label>
              <Input id="x1" value={x1} onChange={(e) => setX1(e.target.value)} type="number" step="any" required />
            </div>
            <div className="space-y-2">
              <label htmlFor="y1" className="text-sm font-medium">
                Y₁
              </label>
              <Input id="y1" value={y1} onChange={(e) => setY1(e.target.value)} type="number" step="any" required />
            </div>
            <div className="space-y-2">
              <label htmlFor="x2" className="text-sm font-medium">
                X₂
              </label>
              <Input id="x2" value={x2} onChange={(e) => setX2(e.target.value)} type="number" step="any" required />
            </div>
            <div className="space-y-2">
              <label htmlFor="y2" className="text-sm font-medium">
                Y₂
              </label>
              <Input id="y2" value={y2} onChange={(e) => setY2(e.target.value)} type="number" step="any" required />
            </div>
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Calculating..." : "Calculate Slope"}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <div className="mt-4">
            <div className="rounded-md bg-emerald-50 p-4 dark:bg-emerald-950/30">
              <div className="text-center">
                <div className="text-sm font-medium">Slope:</div>
                <div className="text-2xl font-bold">{result.slope}</div>
                <div className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  m = (y₂ - y₁) / (x₂ - x₁) = ({y2} - {y1}) / ({x2} - {x1})
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
