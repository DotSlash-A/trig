import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import DifferentiateSimple from "@/components/differentiate-simple"
import DifferentiateSteps from "@/components/differentiate-steps"
import IntegrateSimple from "@/components/integrate-simple"
import IntegrateSteps from "@/components/integrate-steps"
import SlopeCalculator from "@/components/slope-calculator"
import PowerOfI from "@/components/power-of-i"
import ComplexArithmetic from "@/components/complex-arithmetic"
import CircleEquation from "@/components/circle-equation"
import CircleDetails from "@/components/circle-details"
import CircleFromPoints from "@/components/circle-from-points"
import CircleFromPointsDet from "@/components/circle-from-points-det"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <h1 className="mb-8 text-center text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
          Mathematical Operations
        </h1>

        <Tabs defaultValue="differentiate" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-6 mb-8">
            <TabsTrigger value="differentiate">Differentiate</TabsTrigger>
            <TabsTrigger value="integrate">Integrate</TabsTrigger>
            <TabsTrigger value="slope">Slope</TabsTrigger>
            <TabsTrigger value="complex">Complex Numbers</TabsTrigger>
            <TabsTrigger value="circle">Circle</TabsTrigger>
            <TabsTrigger value="circle-points">Circle from Points</TabsTrigger>
          </TabsList>

          <TabsContent value="differentiate" className="space-y-8">
            <div className="grid gap-8 md:grid-cols-2">
              <DifferentiateSimple />
              <DifferentiateSteps />
            </div>
          </TabsContent>

          <TabsContent value="integrate" className="space-y-8">
            <div className="grid gap-8 md:grid-cols-2">
              <IntegrateSimple />
              <IntegrateSteps />
            </div>
          </TabsContent>

          <TabsContent value="slope" className="space-y-8">
            <div className="grid gap-8 md:grid-cols-2">
              <SlopeCalculator />
              <PowerOfI />
            </div>
          </TabsContent>

          <TabsContent value="complex" className="space-y-8">
            <ComplexArithmetic />
          </TabsContent>

          <TabsContent value="circle" className="space-y-8">
            <div className="grid gap-8 md:grid-cols-2">
              <CircleEquation />
              <CircleDetails />
            </div>
          </TabsContent>

          <TabsContent value="circle-points" className="space-y-8">
            <div className="grid gap-8 md:grid-cols-2">
              <CircleFromPoints />
              <CircleFromPointsDet />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
