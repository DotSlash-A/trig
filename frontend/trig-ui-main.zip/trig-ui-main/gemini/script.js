document.addEventListener("DOMContentLoaded", () => {
  const sidebarLinks = document.querySelectorAll(".sidebar nav a");
  const operationSections = document.querySelectorAll(".operation-section");
  const forms = document.querySelectorAll("form");
  const API_BASE_URL = "http://localhost:8000"; // Your API base URL

  // --- Navigation ---
  function showSection(targetId) {
    operationSections.forEach((section) => {
      section.style.display = section.id === targetId ? "block" : "none";
    });
    sidebarLinks.forEach((link) => {
      link.classList.toggle("active", link.dataset.target === targetId);
    });
    // Scroll to top of main content might be nice on mobile
    document.querySelector(".main-content").scrollTop = 0;
  }

  sidebarLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      showSection(link.dataset.target);
    });
  });

  // Show the first section by default
  if (sidebarLinks.length > 0) {
    showSection(sidebarLinks[0].dataset.target);
  }

  // --- API Call Helper ---
  async function callApi(url, method = "POST", body = null) {
    const outputElementId = `output-${url
      .split("/")
      .pop()
      .split("?")[0]
      .replace(/_/g, "-")}`; // Derive output element ID convention
    const outputArea =
      document.getElementById(outputElementId) ||
      document.querySelector(`#${currentFormId.replace("form-", "output-")}`); // Fallback using active form ID

    if (!outputArea) {
      console.error("Could not find output area for URL:", url);
      return; // Or handle more gracefully
    }

    outputArea.innerHTML = "Loading...";
    outputArea.className = "output-area loading"; // Reset classes

    try {
      const options = {
        method: method,
        headers: {
          accept: "application/json",
        },
      };

      if (method === "POST" && body) {
        // Only add Content-Type if there's a body
        options.headers["Content-Type"] = "application/json";
        options.body = JSON.stringify(body);
      } else if (method === "POST" && !body) {
        // Handle POST with empty body specifically (like power of i)
        options.body = ""; // Send empty string
        options.headers["Content-Type"] = "application/json"; // FastAPI might still expect this
      }

      const response = await fetch(url, options);

      if (!response.ok) {
        let errorMsg = `HTTP error! Status: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMsg += ` - ${errorData.detail || JSON.stringify(errorData)}`;
        } catch (e) {
          errorMsg += ` - ${response.statusText}`;
        }
        throw new Error(errorMsg);
      }

      const data = await response.json();
      displayResult(outputArea, data, url); // Pass URL to customize display
    } catch (error) {
      console.error("API Call Error:", error);
      outputArea.innerHTML = `Error: ${error.message}`;
      outputArea.className = "output-area error";
    }
  }

  // --- Result Display ---
  function displayResult(outputArea, data, url) {
    outputArea.innerHTML = ""; // Clear loading message
    outputArea.className = "output-area"; // Reset class

    // Customize display based on the API endpoint (derived from URL)
    if (url.includes("/differentiate/simple")) {
      outputArea.innerHTML = `
              <p><strong>Original:</strong> <code>${
                data.original_expression
              }</code> (w.r.t. <code>${data.variable}</code>)</p>
              <p><strong>Derivative:</strong></p>
              <div class="math-latex">$$${convertToMathJax(
                data.derivative
              )}$$</div>
          `;
    } else if (url.includes("/differentiate/steps")) {
      outputArea.innerHTML = `
              <p><strong>Original:</strong> <code>${
                data.original_expression
              }</code> (w.r.t. <code>${data.variable}</code>)</p>
              <p><strong>Steps:</strong></p>
              ${data.steps
                .map(
                  (step) => `
                  <div class="step">
                      <div class="step-description">${
                        step.step_description
                      }</div>
                      ${
                        step.expression_latex
                          ? `<div class="math-latex">$$${step.expression_latex}$$</div>`
                          : ""
                      }
                      ${
                        step.expression_pretty
                          ? `<pre>${step.expression_pretty}</pre>`
                          : ""
                      }
                  </div>
              `
                )
                .join("")}
              <p><strong>Final Derivative:</strong></p>
               <div class="math-latex">$$${convertToMathJax(
                 data.final_derivative
               )}$$</div>
          `;
    } else if (url.includes("/integrate/integrate/simple")) {
      outputArea.innerHTML = `
              <p><strong>Original:</strong> <code>${
                data.original_expression
              }</code> (w.r.t. <code>${data.variable}</code>)</p>
              <p><strong>Integral Result:</strong></p>
              <pre>${data.integral_result || "Not found"}</pre>
              ${
                data.computation_notes
                  ? `<p><strong>Notes:</strong> ${data.computation_notes}</p>`
                  : ""
              }
          `;
    } else if (url.includes("/integrate/integrate/steps")) {
      outputArea.innerHTML = `
              <p><strong>Original:</strong> <code>${
                data.original_expression
              }</code> (w.r.t. <code>${data.variable}</code>)</p>
              <p><strong>Steps:</strong></p>
               ${data.steps
                 .map(
                   (step) => `
                  <div class="step">
                      <div class="step-description">${
                        step.step_description
                      }</div>
                       ${
                         step.expression_latex
                           ? `<div class="math-latex">$$${step.expression_latex}$$</div>`
                           : ""
                       }
                      ${
                        step.expression_pretty
                          ? `<pre>${step.expression_pretty}</pre>`
                          : ""
                      }
                  </div>
              `
                 )
                 .join("")}
              <p><strong>Final Integral:</strong></p>
              <pre>${data.final_integral || "Not found"}</pre>
               ${
                 data.computation_notes
                   ? `<p><strong>Notes:</strong> ${data.computation_notes}</p>`
                   : ""
               }
          `;
    } else if (url.includes("/SlopeCordiantes")) {
      outputArea.innerHTML = `<p><strong>Calculated Slope:</strong> ${data.slope}</p>`;
    } else if (url.includes("/powers")) {
      outputArea.innerHTML = `<p><strong>Result (i<sup>n</sup>):</strong> ${data.result}</p>`;
    } else if (url.includes("/arithmetic")) {
      outputArea.innerHTML = `<p><strong>Result:</strong> ${data.result}</p>`;
    } else if (url.includes("/circle/eqn")) {
      outputArea.innerHTML = `
              <p><strong>Input:</strong> Center (${data.center_h}, ${data.center_k}), Radius ${data.radius}</p>
              <p><strong>Standard Form:</strong> <code>${data.standard_form}</code></p>
              <p><strong>General Form:</strong> <code>${data.general_form}</code></p>
              <!-- Optionally display A, B, C, D, E if needed -->
           `;
    } else if (url.includes("/circle/details")) {
      outputArea.innerHTML = `
              <p><strong>Input Equation:</strong> <code>${data.input_equation}</code></p>
              <p><strong>Normalized Equation:</strong> <code>${data.normalized_equation}</code></p>
              <p><strong>Center (h, k):</strong> (${data.center_h}, ${data.center_k})</p>
              <p><strong>Radius (r):</strong> ${data.radius}</p>
           `;
    } else if (url.includes("/circle/3points")) {
      // Covers both 3points and 3points/det1
      outputArea.innerHTML = `
              <p><strong>Calculated Equation:</strong></p>
              <code>${
                data.standard_form ||
                data.circle_equation ||
                JSON.stringify(data)
              }</code>
           `;
    } else {
      // Default fallback display
      outputArea.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    }

    // Re-render MathJax content if needed
    if (outputArea.querySelector(".math-latex")) {
      MathJax.typesetPromise([outputArea]).catch(function (err) {
        console.error("MathJax Typesetting Error:", err);
        outputArea.innerHTML +=
          '<p style="color: red;">Error rendering math expressions.</p>';
      });
    }
  }

  // Helper to attempt basic conversion from SymPy pretty print to LaTeX for simple cases
  function convertToMathJax(expr) {
    if (!expr || typeof expr !== "string") return "";
    // Very basic replacements - extend as needed
    let latex = expr
      .replace(/\*\*/g, "^") // Power
      .replace(/\*/g, "\\cdot ") // Multiplication (cdot)
      .replace(/sin\(/g, "\\sin(")
      .replace(/cos\(/g, "\\cos(")
      .replace(/tan\(/g, "\\tan(")
      // Add more replacements if necessary (e.g., sqrt, fractions)
      .replace(/sqrt\((.*?)\)/g, "\\sqrt{$1}");
    return latex;
  }

  // --- Form Submission Logic ---
  let currentFormId = ""; // Keep track of the current form

  forms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      currentFormId = form.id; // Store which form was submitted
      let url;
      let body;
      let method = "POST"; // Default to POST

      // Determine URL and body based on form ID
      switch (form.id) {
        case "form-diff-simple":
          url = `${API_BASE_URL}/differentiate/simple`;
          body = {
            expression: document.getElementById("diff-simple-expr").value,
            variable: document.getElementById("diff-simple-var").value,
          };
          break;
        case "form-diff-steps":
          url = `${API_BASE_URL}/differentiate/steps`;
          body = {
            expression: document.getElementById("diff-steps-expr").value,
            variable: document.getElementById("diff-steps-var").value,
          };
          break;
        case "form-int-simple":
          url = `${API_BASE_URL}/integrate/integrate/simple`;
          body = {
            expression: document.getElementById("int-simple-expr").value,
            variable: document.getElementById("int-simple-var").value,
          };
          break;
        case "form-int-steps":
          url = `${API_BASE_URL}/integrate/integrate/steps`;
          body = {
            expression: document.getElementById("int-steps-expr").value,
            variable: document.getElementById("int-steps-var").value,
          };
          break;
        case "form-slope":
          url = `${API_BASE_URL}/SlopeCordiantes`;
          body = {
            x1: parseFloat(document.getElementById("slope-x1").value),
            y1: parseFloat(document.getElementById("slope-y1").value),
            x2: parseFloat(document.getElementById("slope-x2").value),
            y2: parseFloat(document.getElementById("slope-y2").value),
          };
          break;
        case "form-power-i":
          const n = document.getElementById("power-i-n").value;
          url = `${API_BASE_URL}/powers?n=${encodeURIComponent(n)}`;
          body = null; // Empty body, data is in query param
          // For FastAPI, POST with empty body might need explicit empty string
          body = "";
          break;
        case "form-complex-arith":
          url = `${API_BASE_URL}/arithmetic`;
          body = {
            z1: {
              real: parseFloat(
                document.getElementById("complex-z1-real").value
              ),
              img: parseFloat(document.getElementById("complex-z1-img").value),
            },
            z2: {
              real: parseFloat(
                document.getElementById("complex-z2-real").value
              ),
              img: parseFloat(document.getElementById("complex-z2-img").value),
            },
            operation: document.getElementById("complex-op").value,
          };
          break;
        case "form-circle-eqn":
          url = `${API_BASE_URL}/circle/eqn`;
          body = {
            h: parseFloat(document.getElementById("circle-eqn-h").value),
            k: parseFloat(document.getElementById("circle-eqn-k").value),
            r: parseFloat(document.getElementById("circle-eqn-r").value),
          };
          break;
        case "form-circle-details":
          url = `${API_BASE_URL}/circle/details`;
          body = {
            equation: document.getElementById("circle-details-eqn").value,
          };
          break;
        case "form-circle-3pt":
          url = `${API_BASE_URL}/circle/3points`;
          body = {
            p: {
              x: parseFloat(document.getElementById("circle-3pt-px").value),
              y: parseFloat(document.getElementById("circle-3pt-py").value),
            },
            q: {
              x: parseFloat(document.getElementById("circle-3pt-qx").value),
              y: parseFloat(document.getElementById("circle-3pt-qy").value),
            },
            r: {
              x: parseFloat(document.getElementById("circle-3pt-rx").value),
              y: parseFloat(document.getElementById("circle-3pt-ry").value),
            },
          };
          break;
        case "form-circle-3pt-det":
          url = `${API_BASE_URL}/circle/3points/det1`;
          body = {
            p: {
              x: parseFloat(document.getElementById("circle-3pt-det-px").value),
              y: parseFloat(document.getElementById("circle-3pt-det-py").value),
            },
            q: {
              x: parseFloat(document.getElementById("circle-3pt-det-qx").value),
              y: parseFloat(document.getElementById("circle-3pt-det-qy").value),
            },
            r: {
              x: parseFloat(document.getElementById("circle-3pt-det-rx").value),
              y: parseFloat(document.getElementById("circle-3pt-det-ry").value),
            },
          };
          break;

        default:
          console.error("Unknown form submitted:", form.id);
          return; // Don't proceed if form ID isn't recognized
      }

      // Call the API
      callApi(url, method, body);
    });
  });
});
